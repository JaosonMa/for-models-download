/********************************************************************************
** Form generated from reading UI file 'vcpkgdebugerrortest.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VCPKGDEBUGERRORTEST_H
#define UI_VCPKGDEBUGERRORTEST_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_vcpkgdebugerrortestClass
{
public:
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QWidget *centralWidget;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *vcpkgdebugerrortestClass)
    {
        if (vcpkgdebugerrortestClass->objectName().isEmpty())
            vcpkgdebugerrortestClass->setObjectName(QString::fromUtf8("vcpkgdebugerrortestClass"));
        vcpkgdebugerrortestClass->resize(600, 400);
        menuBar = new QMenuBar(vcpkgdebugerrortestClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        vcpkgdebugerrortestClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(vcpkgdebugerrortestClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        vcpkgdebugerrortestClass->addToolBar(mainToolBar);
        centralWidget = new QWidget(vcpkgdebugerrortestClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        vcpkgdebugerrortestClass->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(vcpkgdebugerrortestClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        vcpkgdebugerrortestClass->setStatusBar(statusBar);

        retranslateUi(vcpkgdebugerrortestClass);

        QMetaObject::connectSlotsByName(vcpkgdebugerrortestClass);
    } // setupUi

    void retranslateUi(QMainWindow *vcpkgdebugerrortestClass)
    {
        vcpkgdebugerrortestClass->setWindowTitle(QCoreApplication::translate("vcpkgdebugerrortestClass", "vcpkgdebugerrortest", nullptr));
    } // retranslateUi

};

namespace Ui {
    class vcpkgdebugerrortestClass: public Ui_vcpkgdebugerrortestClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VCPKGDEBUGERRORTEST_H
